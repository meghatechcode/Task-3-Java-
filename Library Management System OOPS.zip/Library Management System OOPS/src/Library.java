import java.util.ArrayList;
import java.util.Scanner;
 public class Library {
            private ArrayList<Book> books;
            private ArrayList<User> users;

            public Library() {
                books = new ArrayList<>();
                users = new ArrayList<>();
            }

            public void addBook(Book book) {
                books.add(book);
            }

            public void addUser(User user) {
                users.add(user);
            }

            public void showBooks() {
                System.out.println("\n--- Book List ---");
                for (Book book : books) {
                    System.out.println(book);
                }
            }

            public void showUsers() {
                System.out.println("\n--- Registered Users ---");
                for (User user : users) {
                    System.out.println(user);
                }
            }

            public void issueBook(String title) {
                for (Book book : books) {
                    if (book.getTitle().equalsIgnoreCase(title)) {
                        if (!book.isIssued()) {
                            book.issueBook();
                            System.out.println("Book issued successfully.");
                        } else {
                            System.out.println("Book is already issued.");
                        }
                        return;
                    }
                }
                System.out.println("Book not found.");
            }

            public void returnBook(String title) {
                for (Book book : books) {
                    if (book.getTitle().equalsIgnoreCase(title)) {
                        if (book.isIssued()) {
                            book.returnBook();
                            System.out.println("Book returned successfully.");
                        } else {
                            System.out.println("This book wasn't issued.");
                        }
                        return;
                    }
                }
                System.out.println("Book not found.");
            }

            public static void main(String[] args) {
                Library library = new Library();
                Scanner scanner = new Scanner(System.in);

                // Add sample data
                library.addBook(new Book("Let us C", "Yashavant P Kanetkar"));
                library.addBook(new Book("Java Fundamentals", "Herbert Schildt"));
                library.addUser(new User(101, "Aniket"));
                library.addUser(new User(102, "Bobby"));

                int choice;
                do {
                    System.out.println("\n===== Library Menu =====");
                    System.out.println("1. View Books");
                    System.out.println("2. View Users");
                    System.out.println("3. Issue Book");
                    System.out.println("4. Return Book");
                    System.out.println("0. Exit");
                    System.out.print("Enter choice: ");
                    choice = scanner.nextInt();
                    scanner.nextLine(); // clear buffer

                    switch (choice) {
                        case 1:
                            library.showBooks();
                            break;
                        case 2:
                            library.showUsers();
                            break;
                        case 3:
                            System.out.print("Enter book title to issue: ");
                            String issueTitle = scanner.nextLine();
                            library.issueBook(issueTitle);
                            break;
                        case 4:
                            System.out.print("Enter book title to return: ");
                            String returnTitle = scanner.nextLine();
                            library.returnBook(returnTitle);
                            break;
                        case 0:
                            System.out.println("Exiting the system. Goodbye!");
                            break;
                        default:
                            System.out.println("Invalid choice.");
                    }

                } while (choice != 0);

                scanner.close();
            }
        }




